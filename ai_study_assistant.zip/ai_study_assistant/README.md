# AI Study Assistant (Python)

## Chức năng
- Tải nhiều tài liệu PDF, DOCX, TXT.
- Trích xuất văn bản từ tài liệu.
- Chia văn bản thành các đoạn nhỏ có phần chồng lấp.
- Lập chỉ mục tìm kiếm TF-IDF và truy xuất các đoạn liên quan.
- Gửi câu hỏi cùng ngữ cảnh tìm được tới OpenAI API.
- Hiển thị câu trả lời và nguồn tài liệu, gồm số trang khi xác định được.

## 1. Cài đặt
Cài Python 3.10 trở lên. Mở Terminal trong thư mục dự án:

```bash
python -m venv .venv
```

Windows:
```powershell
.venv\Scripts\activate
pip install -r requirements.txt
```

macOS/Linux:
```bash
source .venv/bin/activate
pip install -r requirements.txt
```

## 2. Chạy ứng dụng
```bash
streamlit run app.py
```

Mở địa chỉ local mà Streamlit hiển thị, thường là http://localhost:8501.

## 3. Sử dụng
1. Nhập OpenAI API key ở thanh bên. Có thể lấy khóa từ trang quản lý API của OpenAI.
2. Tải file PDF/DOCX/TXT lên.
3. Bấm **Xử lý tài liệu**.
4. Nhập câu hỏi vào khung chat.
5. Mở **Xem nguồn tài liệu** để kiểm tra đoạn văn bản được sử dụng.

## Bảo mật
- Không đưa API key lên GitHub hoặc chia sẻ cho người khác.
- Ứng dụng mẫu giữ tài liệu trong bộ nhớ phiên, chưa có đăng nhập, phân quyền hoặc lưu trữ lâu dài.
- PDF scan cần OCR để nhận dạng chữ; phiên bản mẫu chưa tích hợp OCR.
- Câu trả lời AI có thể sai; luôn kiểm tra nội dung và nguồn.

## Cấu trúc
```text
ai_study_assistant/
├── app.py
├── requirements.txt
└── README.md
```
