import os
import re
from io import BytesIO
from typing import List, Dict, Any

import streamlit as st
import fitz
from docx import Document
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from openai import OpenAI

st.set_page_config(page_title="AI Study Assistant", page_icon="🎓", layout="wide")

st.title("🎓 AI Study Assistant")
st.caption("Tải tài liệu môn học lên, đặt câu hỏi và nhận câu trả lời kèm nguồn tham khảo.")

def extract_text(uploaded_file) -> List[Dict[str, Any]]:
    name = uploaded_file.name
    data = uploaded_file.getvalue()
    ext = name.lower().rsplit(".", 1)[-1]

    pages = []
    if ext == "pdf":
        pdf = fitz.open(stream=data, filetype="pdf")
        for i, page in enumerate(pdf):
            text = page.get_text("text").strip()
            if text:
                pages.append({"text": text, "page": i + 1})
    elif ext == "docx":
        doc = Document(BytesIO(data))
        text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        if text:
            pages.append({"text": text, "page": None})
        for table in doc.tables:
            table_text = "\n".join(" | ".join(cell.text.strip() for cell in row.cells) for row in table.rows)
            if table_text.strip():
                pages.append({"text": table_text, "page": None})
    elif ext == "txt":
        text = data.decode("utf-8", errors="replace").strip()
        if text:
            pages.append({"text": text, "page": None})
    else:
        raise ValueError("Định dạng chưa được hỗ trợ.")
    return pages

def split_into_chunks(text: str, chunk_size: int = 900, overlap: int = 150) -> List[str]:
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        if end < len(text):
            boundary = text.rfind(" ", start + int(chunk_size * 0.65), end)
            if boundary > start:
                end = boundary
        piece = text[start:end].strip()
        if piece:
            chunks.append(piece)
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return chunks

def build_chunks(files) -> List[Dict[str, Any]]:
    all_chunks = []
    seen = set()
    for file in files:
        try:
            pages = extract_text(file)
        except Exception as exc:
            st.warning(f"Không đọc được {file.name}: {exc}")
            continue

        for page_data in pages:
            for index, chunk in enumerate(split_into_chunks(page_data["text"])):
                key = (file.name, page_data["page"], chunk)
                if key in seen:
                    continue
                seen.add(key)
                all_chunks.append({
                    "source": file.name,
                    "page": page_data["page"],
                    "chunk_index": index + 1,
                    "text": chunk
                })
    return all_chunks

def retrieve(question: str, chunks: List[Dict[str, Any]], top_k: int = 4):
    if not chunks:
        return []
    corpus = [item["text"] for item in chunks]
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), max_features=30000)
    matrix = vectorizer.fit_transform(corpus + [question])
    scores = cosine_similarity(matrix[-1], matrix[:-1]).ravel()
    best_indices = scores.argsort()[::-1][:top_k]
    results = []
    for idx in best_indices:
        if scores[idx] > 0:
            result = dict(chunks[idx])
            result["score"] = float(scores[idx])
            results.append(result)
    return results

def generate_answer(question: str, sources: List[Dict[str, Any]], api_key: str, model: str):
    if not sources:
        return "Tôi chưa tìm thấy đoạn tài liệu đủ liên quan để trả lời. Hãy thử hỏi theo cách khác hoặc tải thêm tài liệu."

    context_parts = []
    for i, item in enumerate(sources, start=1):
        page_text = f", trang {item['page']}" if item.get("page") else ""
        context_parts.append(
            f"[Nguồn {i}: {item['source']}{page_text}]\n{item['text']}"
        )
    context = "\n\n".join(context_parts)

    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=model,
        temperature=0.2,
        messages=[
            {
                "role": "system",
                "content": (
                    "Bạn là trợ lý học tập. Trả lời bằng tiếng Việt rõ ràng, dễ hiểu, "
                    "ưu tiên nội dung trong ngữ cảnh tài liệu được cung cấp. "
                    "Không bịa thông tin hoặc nguồn. Nếu tài liệu không đủ để kết luận, "
                    "hãy nói rõ điều đó. Khi phù hợp, dẫn nguồn theo dạng [Nguồn 1], [Nguồn 2]."
                )
            },
            {
                "role": "user",
                "content": f"Câu hỏi:\n{question}\n\nĐoạn tài liệu tìm được:\n{context}"
            }
        ]
    )
    return response.choices[0].message.content or "AI không trả về nội dung."

with st.sidebar:
    st.header("⚙️ Cài đặt")
    api_key_input = st.text_input(
        "OpenAI API key",
        type="password",
        value=os.getenv("OPENAI_API_KEY", ""),
        help="Khóa API được dùng để tạo câu trả lời. Không chia sẻ khóa này."
    )
    model = st.text_input("Tên model", value="gpt-4o-mini")
    top_k = st.slider("Số đoạn tài liệu tìm kiếm", min_value=1, max_value=8, value=4)
    st.info("Tìm kiếm tài liệu dùng TF-IDF tại máy. API AI chỉ được gọi khi bạn gửi câu hỏi.")

uploaded_files = st.file_uploader(
    "📚 Tải tài liệu môn học (PDF, DOCX, TXT)",
    type=["pdf", "docx", "txt"],
    accept_multiple_files=True
)

if "chunks" not in st.session_state:
    st.session_state.chunks = []
if "indexed_names" not in st.session_state:
    st.session_state.indexed_names = []
if "messages" not in st.session_state:
    st.session_state.messages = []

col1, col2 = st.columns([1, 3])
with col1:
    if st.button("Xử lý tài liệu", type="primary", use_container_width=True):
        if not uploaded_files:
            st.error("Vui lòng tải lên ít nhất một tài liệu.")
        else:
            with st.spinner("Đang trích xuất, chia đoạn và lập chỉ mục..."):
                st.session_state.chunks = build_chunks(uploaded_files)
                st.session_state.indexed_names = [f.name for f in uploaded_files]
                st.session_state.messages = []
            if st.session_state.chunks:
                st.success(f"Đã xử lý {len(st.session_state.indexed_names)} tài liệu, tạo {len(st.session_state.chunks)} đoạn.")
            else:
                st.error("Không trích xuất được văn bản. Nếu PDF là bản scan, cần OCR trước.")

with col2:
    if st.session_state.chunks:
        st.write("**Tài liệu đã lập chỉ mục:** " + ", ".join(st.session_state.indexed_names))

st.divider()
st.subheader("💬 Hỏi đáp với tài liệu")

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if message.get("sources"):
            with st.expander("Xem nguồn tài liệu"):
                for i, source in enumerate(message["sources"], start=1):
                    page_text = f" — trang {source['page']}" if source.get("page") else ""
                    st.markdown(f"**[Nguồn {i}] {source['source']}{page_text}**")
                    st.caption(f"Độ liên quan tìm kiếm: {source['score']:.3f}")
                    st.write(source["text"])

question = st.chat_input("Ví dụ: Hãy giải thích khái niệm chính trong chương 1...")
if question:
    if not st.session_state.chunks:
        st.warning("Bạn cần tải tài liệu và bấm “Xử lý tài liệu” trước.")
    elif not api_key_input:
        st.error("Nhập OpenAI API key ở thanh bên để bật chức năng trả lời AI.")
    else:
        st.session_state.messages.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)

        relevant = retrieve(question, st.session_state.chunks, top_k=top_k)
        with st.chat_message("assistant"):
            with st.spinner("Đang tìm nguồn và tạo câu trả lời..."):
                try:
                    answer = generate_answer(question, relevant, api_key_input, model)
                    st.markdown(answer)
                    if relevant:
                        with st.expander("Xem nguồn tài liệu"):
                            for i, source in enumerate(relevant, start=1):
                                page_text = f" — trang {source['page']}" if source.get("page") else ""
                                st.markdown(f"**[Nguồn {i}] {source['source']}{page_text}**")
                                st.caption(f"Độ liên quan tìm kiếm: {source['score']:.3f}")
                                st.write(source["text"])
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": answer,
                        "sources": relevant
                    })
                except Exception as exc:
                    st.error(f"Không thể tạo câu trả lời: {exc}")
                    st.info("Kiểm tra API key, tên model và kết nối Internet.")
                    st.session_state.messages.pop()

with st.expander("ℹ️ Lưu ý"):
    st.write(
        "Ứng dụng hiện giữ tài liệu và lịch sử trong phiên chạy Streamlit, chưa lưu lâu dài vào cơ sở dữ liệu. "
        "PDF dạng ảnh scan có thể không trích xuất được chữ. Với tài liệu quan trọng, hãy kiểm tra lại câu trả lời "
        "và nguồn trích dẫn trước khi sử dụng."
    )
